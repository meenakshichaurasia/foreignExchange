export const environment = {
  production: false,
  API_ENDPOINT: 'https://crudcrud.com/api/a054ae7e6b9741e185c63d211dbf29c1',
};
