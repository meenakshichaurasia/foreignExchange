export interface Market {
  _id: string;
  market: string;
  buyingPrice: string;
  sellingPrice: string;
}
